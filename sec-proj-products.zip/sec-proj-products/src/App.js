import React, { useEffect, useState } from "react";
import Cart from "./Cart";
import "./App.css";

const App = () => {
  const [posts, setPost] = useState([]);

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then((res) => res.json())
      .then((temp) => setPost(temp.products)) 
      .catch((e) => console.log(e));
  }, []);

  return (
    <div>
      <h1 style={{ textAlign: "center" }}>Product Cart</h1>
      <div className="cart-container">
        {posts.map((temp) => (
          <Cart
            key={temp.id}
            id={temp.id}
            title={temp.title}
            image={temp.thumbnail}  
            price={temp.price}
            category={temp.category}
          />
        ))}
      </div>
    </div>
  );
};
export default App;
