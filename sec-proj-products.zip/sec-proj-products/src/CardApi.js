import { useEffect, useState } from "react";
import Card from "./Card";
import "./App.css";

const CardApi = () => {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then((res) => res.json())
      .then((data) => setProducts(data.products));
  }, []);
  const handleAdd = () => {
    const newProduct = {
      id: products.length + 1,
      title,
      category,
      price,
      thumbnail: image,
    };
    setProducts([newProduct, ...products]);
    setTitle(""); setCategory(""); setPrice(""); setImage("");
  };

  const filtered = products.filter((p) =>
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "20px" }}>
      <h3>Add Product</h3>
      <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} />
      <input placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} />
      <input placeholder="Image URL" value={image} onChange={(e) => setImage(e.target.value)} />
      <button onClick={handleAdd}>Add</button>

      <br /><br />
      <input placeholder="Search by category" value={search} onChange={(e) => setSearch(e.target.value)} />
        {filtered.map((p) => (
          <Card key={p.id} {...p} />
        ))}
      </div>
  );
};
export default CardApi;
