import React from "react";
import "./App.css";

const Cart = ({ id, title, image, price, category }) => {
  return (
    <div className="product-card">
      <img src={image} alt={title} />
      <h3>{title}</h3>
      <p><strong>ID:</strong> {id}</p>
      <p><strong>Price:</strong> ${price}</p>
      <p><strong>Category:</strong> {category}</p>
    </div>
  );
};

export default Cart;
