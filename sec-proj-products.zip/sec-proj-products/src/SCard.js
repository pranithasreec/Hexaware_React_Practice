import React from 'react'
import {
  CardMeta,
  CardHeader,
  CardDescription,
  CardContent,
  Card,
  Icon,
  Image,
} from 'semantic-ui-react'
 
const SCard = ({id,title,pic,category,RemoveData}) => (
  <Card>
    <Image src={pic} wrapped ui={false} />
    <CardContent>
      <CardHeader>{id}</CardHeader>
     
      <CardDescription>
    {title}
      </CardDescription>
    </CardContent>
    <CardContent extra>
      <a>
        <Icon name='user' />
        category
      </a>
    </CardContent>
 
     <button onClick={()=>RemoveData(id)}> Remove </button>
 <button class="ui button">Click Here</button>
 
 
  </Card>
)
 
export default SCard