import React from 'react';
import ProductCard from './ProductCard';
import { useDispatch } from 'react-redux';
import { addToCart } from '../Redux/cartSlice';

const watches = [

  {

    id: 1,

    name: "Classic Leather Watch",

    price: 1500,

    image: "https://cdn.shopify.com/s/files/1/1441/7726/products/4_097a5638-cde9-450c-9271-ab22f06358ec_360x.png?v=1602669722"

  },

  {

    id: 2,

    name: "Digital Sport Watch",

    price: 900,

    image: "https://aws.wideinfo.org/fanzlive.com/wp-content/uploads/2017/12/07174936/Boys-Watch-Sports-Watch-Electronic-Quartz-Digital-Watches-for-boy-Water-Resistant-Timsty-B0183UDXHA-1.jpg"

  },

  {

    id: 3,

    name: "Luxury Gold Watch",

    price: 3500,

    image: "https://files.sophie.co.ke/2023/05/1955044573_8664-1_9826.jpg"

  },

  {

    id: 4,

    name: "Smartwatch",

    price: 2500,

    image: "https://zerolifestyle.co/cdn/shop/files/Beauty.03.png?v=1715345647"

  },

  {

    id: 5,

    name: "Analog Wrist Watch",

    price: 1200,

    image: "https://images.squarespace-cdn.com/content/v1/5c78138211f784469d4817df/ad1e0ef7-c373-4662-8257-fcc9f156300b/468BDB8F-497D-4656-9480-22D303DF8DE4.jpeg?format=1500w"

  },

  {

    id: 6,

    name: "Stainless Steel Watch",

    price: 1800,

    image: "https://luxurywatchbd.com/wp-content/uploads/2022/08/1.jpg"

  },

  {

    id: 7,

    name: "Chronograph Watch",

    price: 2200,

    image: "https://tse1.mm.bing.net/th/id/OIP.09wXBVqgR6v6yF1WNfShEAHaE8?pid=Api&P=0&h=180"

  },

  {

    id: 8,

    name: "Minimalist Watch",

    price: 1000,

    image: "https://tse3.mm.bing.net/th/id/OIP.LAInYvddNcL3DuXqLmUDFQAAAA?pid=Api&P=0&h=180"

  },

  {

    id: 9,

    name: "Digital LED Watch",

    price: 800,

    image: "https://tse2.mm.bing.net/th/id/OIP.H92c81dlYvdN7nQ7cu03LAHaHa?pid=Api&P=0&h=180"

  },

  {

    id: 10,

    name: "Military Tactical Watch",

    price: 2000,

    image: "https://cdn.everydaycarry.com/uploads/22-06-23/162b4942aa2979.jpg"

  }

];

const WatchList = () => {
  const dispatch = useDispatch();

  return (
    <div>
      <h2> Watch Collection</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {watches.map(watch => (
          <ProductCard
            key={watch.id}
            name={watch.name}
            price={watch.price}
            image={watch.image}
            onAdd={() => dispatch(addToCart(watch))}
          />
        ))}
      </div>
    </div>
  );
};

export default WatchList;
