import React from 'react';
import ProductCard from './ProductCard';
import { useDispatch } from 'react-redux';
import { addToCart } from '../Redux/cartSlice';

const flowers = [
  {
    id: 'f1',
    name: "Rose",
    price: 50,
    image: "https://sp.yimg.com/ib/th/id/OIP.4_p9tw3EpIsLMUAMd8VdFwHaJ4?pid=Api&w=148&h=148&c=7&dpr=2&rs=1"
  },
  {
    id: 'f2',
    name: "Tulip",
    price: 40,
    image: "https://tse3.mm.bing.net/th/id/OIP.nzQltACCts1MBewr2AorAQHaE7?pid=Api&P=0&h=180"
  },
  {
    id: 'f3',
    name: "Lily",
    price: 60,
    image: "https://tse3.mm.bing.net/th/id/OIP.HPo1wG_IOeEJ3R04u0mO_gHaE9?pid=Api&P=0&h=180"
  },
  {
    id: 'f4',
    name: "Daisy",
    price: 30,
    image: "https://tse3.mm.bing.net/th/id/OIP.Q1c-c7vevJ87XjzfHOtDMwHaE5?pid=Api&P=0&h=180"
  },
  {
    id: 'f5',
    name: "Sunflower",
    price: 45,
    image: "https://tse3.mm.bing.net/th/id/OIP.Fgcfmhi0GgakM-znzmKNOQHaHa?pid=Api&P=0&h=180"
  },
  {
    id: 'f6',
    name: "Marigold",
    price: 35,
    image: "https://tse2.mm.bing.net/th/id/OIP.vAXQE3uVDgeVBTLQL4dl0QHaHa?pid=Api&P=0&h=180"
  },
  {
    id: 'f7',
    name: "Jasmine",
    price: 55,
    image: "https://tse1.mm.bing.net/th/id/OIP.jF_6d9vBL541ccq-4GydkQHaE8?pid=Api&P=0&h=180"
  },
  {
    id: 'f8',
    name: "Lavender",
    price: 70,
    image: "https://tse2.mm.bing.net/th/id/OIP.Zp6UwVQ9PCfj2XWqx2IVkgHaJ2?pid=Api&P=0&h=180"
  },
  {
    id: 'f9',
    name: "Orchid",
    price: 80,
    image: "https://tse1.mm.bing.net/th/id/OIP.GMXsUffyUuXVm6rQ0xswXAAAAA?pid=Api&P=0&h=180"
  },
  {
    id: 'f10',
    name: "Peony",
    price: 65,
    image: "https://tse1.mm.bing.net/th/id/OIP.uJQiiX8v28io7bOfxmB2BgHaHa?pid=Api&P=0&h=180"
  }
];

const FlowerList = () => {
  const dispatch = useDispatch();

  return (
    <div>
      <h2> Flower Collection</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap', fontSize:1.5,marginBottom: '20px'}}>
        {flowers.map(flower => (
          <ProductCard
            key={flower.id}
            name={flower.name}
            price={flower.price}
            image={flower.image}
            onAdd={() => dispatch(addToCart(flower))}
          />
        ))}
      </div>
    </div>
  );
};

export default FlowerList;
