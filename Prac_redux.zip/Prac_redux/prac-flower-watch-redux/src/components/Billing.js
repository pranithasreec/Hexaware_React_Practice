import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart } from '../Redux/cartSlice';

const Billing = () => {
  const cartItems = useSelector(state => state.cart.cartItems);
  const dispatch = useDispatch(); 

  const total = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <div>
      <h2>🧾 Billing Summary</h2>

      {cartItems.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        cartItems.map(item => (
          <div key={item.id}>
            {item.name} x {item.quantity} = ₹{item.price * item.quantity}
            <button
              className="clear-button"
              onClick={() => dispatch(removeFromCart(item.id))}
              style={{ marginLeft: '10px' }}
            >
              Remove
            </button>
          </div>
        ))
      )}

      <hr />
      <h3>Total: {total}</h3>
    </div>
  );
};

export default Billing;
