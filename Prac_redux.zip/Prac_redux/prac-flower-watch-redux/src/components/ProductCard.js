import React from 'react';
import '../App.css';

const ProductCard = ({ name, price, image, onAdd }) => {
  return (
    <div className="product-card">
      <img src={image} alt={name} className="product-image" />
<div className="product-title">{name}</div>
<div className="product-price">{price}</div>
<button className="product-add-button" onClick={onAdd}>Add to Cart</button>

      

    </div>
    
  );
};

export default ProductCard;
