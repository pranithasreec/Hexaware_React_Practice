import React from 'react';
import FlowerList from './components/FlowerList';
import WatchList from './components/WatchList';
import Billing from './components/Billing';
import { useDispatch } from 'react-redux';
import { clearCart } from './Redux/cartSlice';

const App = () => {
  const dispatch = useDispatch();

  return (
    <div className="App">
      <h1>My Store</h1>
      <button onClick={() => dispatch(clearCart())} style={{ marginBottom: '20px' }}>
        Clear Cart
      </button>

      <FlowerList />
      <WatchList />
      <Billing />
    </div>
  );
};

export default App;
