import { useNavigate } from "react-router-dom"
const Contact=()=>
{
    //If u click here and re-render somewhere else
    const nav=useNavigate()
    const openSignIn=()=>
    {
        nav("/login")
    }
    return(<>
    <h1>Contact</h1>
    <h2>Prani@gmail.com</h2>
    <h2>864230954</h2>
    <button onClick={openSignIn}>Sign In</button>
    </>)
}
export default Contact