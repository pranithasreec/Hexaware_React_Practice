import { Link, Routes, Route } from 'react-router-dom';
import './App.css';
import Home from './Home';
import Contact from './Contact';
import Faq from './Faq';
import Login from './Login';
import Welcome from './Welcome';
import ItemDetails from './ItemDetails';
import Protected from './Protected';

function App() {
  return (
    <div>
      <table border="2">
        <tr>
          <td><Link to="/">Home</Link></td>
          <td><Link to="/faq">FAQ</Link></td>
          <td><Link to="/contact">Contact</Link></td>
          <td><Link to="/login">Login</Link></td>
          <td><Link to="/itemData">View Item</Link></td>
        </tr>
      </table>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/faq" element={<Protected Component={Faq} />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/item/:itemCode" element={<ItemDetails />} />
      </Routes>
    </div>
  );
}

export default App;
