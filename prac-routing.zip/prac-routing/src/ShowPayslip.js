import React from "react";
import TotalSalary from "./TotalSalary";

const ShowPayslip = () => {
  const name = localStorage.getItem("name");
  const id = localStorage.getItem("id");
  const salary = parseFloat(localStorage.getItem("salary"));

  return (
    <div>
      <h3>Payslip Details</h3>
      <p>Name: {name}</p>
      <p>ID: {id}</p>
      <p>Basic Salary: {salary}</p>
      <TotalSalary salary={salary} />
    </div>
  );
};

export default ShowPayslip;
