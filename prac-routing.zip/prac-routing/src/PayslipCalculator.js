import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const PayslipCalculator = () => {
  const [name, setName] = useState("");
  const [id, setId] = useState("");
  const [salary, setSalary] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    localStorage.setItem("name", name);
    localStorage.setItem("id", id);
    localStorage.setItem("salary", salary);

    navigate("/show-payslip");
  };

  return (
    <div>
      <h3>Payslip Calculator</h3>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" onChange={(e) => setName(e.target.value)} required />
        <br />
        <input placeholder="ID" onChange={(e) => setId(e.target.value)} required />
        <br />
        <input
          type="number"
          placeholder="Basic Salary"
          onChange={(e) => setSalary(e.target.value)}
          required
        />
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default PayslipCalculator;
