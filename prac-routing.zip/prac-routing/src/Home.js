const Home = () => {
  return (
    <>
      <h1>Home</h1>
      <h2>Welcome to the Home Page</h2>
      <p>This is the landing page of our website.</p>
    </>
  );
};

export default Home;