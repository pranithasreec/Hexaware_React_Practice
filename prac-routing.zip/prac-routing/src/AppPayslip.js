import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import PayslipCalculator from "./PayslipCalculator";
import ShowPayslip from "./ShowPayslip";
const AppPayslip = () => {
  return (
    <div>
      <h2>Payslip App</h2>
      <Link to="/payslip-calculator">
        <button>Payslip</button>
      </Link>
      <Routes>
        <Route path="/payslip-calculator" element={<PayslipCalculator />} />
        <Route path="/show-payslip" element={<ShowPayslip />} />
      </Routes>
    </div>
  );
};


export default AppPayslip;
