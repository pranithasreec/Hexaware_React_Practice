// src/ItemDetails.js
import React from 'react';
import { useParams } from 'react-router-dom';
import electronicItems from './itemData'; 

const ItemDetails = () => {
  const { itemCode } = useParams();
  const item = electronicItems.find(it => it.itemCode === parseInt(itemCode));

  if (!item) return <h3>Item not found</h3>;

  return (
    <div>
      <h2>Item Details</h2>
      <p>Name: {item.name}</p>
      <p>Item Code: {item.itemCode}</p>
      <p>Price: {item.price}</p>
      <p>Quantity: {item.quantity}</p>
      <p>City: {item.city}</p>
    </div>
  );
};
export default ItemDetails;
