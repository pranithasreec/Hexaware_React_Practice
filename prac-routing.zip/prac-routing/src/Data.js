// src/Data.js
import React, { useState } from 'react';
import UCard from './UCard';
const Data = () => {
  const [users] = useState([
    { UserId: "101", Name: "asha", Salary: 200 },
    { UserId: "102", Name: "ajay", Salary: 400 },
    { UserId: "103", Name: "jatin", Salary: 800 },
    { UserId: "104", Name: "komal", Salary: 700 }
  ]);

  return (
    <div>
      <h2>User Cards</h2>
      {users.map(user => (
        <UCard
          key={user.UserId}
          UserId={user.UserId}
          Name={user.Name}
          Salary={user.Salary}
        />
      ))}
    </div>
  );
};

export default Data;
