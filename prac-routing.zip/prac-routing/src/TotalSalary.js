import React from "react";

const TotalSalary = ({ salary }) => {
  let bonus = 0;

  if (salary <= 5000) {
    bonus = salary * 0.05;
  } else {
    bonus = salary * 0.10;
  }

  const total = salary + bonus;

  return (
    <div>
      <p>Bonus: {bonus}</p>
      <p>Total Salary: {total}</p>
    </div>
  );
};

export default TotalSalary;
