const Faq=()=>
{
    return(<>
    <h1>FAQ</h1>
    <h1>What is the name of your company</h1>
    <h2>My Company name is Ajay</h2>
    </>)
}
export default Faq